# Linear-Equation
Finding the solution of a linear equation in the most efficient way by just entering the coefficients of equation
